# Supabase + Patroni HA Deployment

This repository sets up Supabase (REST, Auth, Studio) leveraging an external high‑availability PostgreSQL backend (Patroni via HAProxy).

## 🚀 Quickstart

1. **Copy and configure** environment:
   ```bash
   cp .env.example .env
   # Edit .env with your HAProxy IP, DB credentials, and JWT keys
   ```

2. **Launch Supabase stack**:
   ```bash
   docker-compose up -d
   ```

3. **Run migrations** (optional but required to setup Supabase schema):
   ```bash
   ./init/migrate.sh
   ```

4. **Access**:
   - Studio UI: http://localhost:3000  
   - API (via Kong + PostgREST): http://localhost:8000

## 🛡️ HA Setup Pre‑Requisite

Ensure your HA PostgreSQL cluster is running and reachable:

- HAProxy should be at `POSTGRES_HOST:POSTGRES_PORT`
- Patroni-managed Postgres behind HAProxy must accept connections

## 📝 Notes

- Supabase’s internal DB service is **removed** — this connects to an external HA setup.
- Use HTTP‑level checks and monitor HAProxy for failover events.
- Customize Kong routing (`init/kong.yml`) as needed.
