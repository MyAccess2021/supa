#!/usr/bin/env bash
set -e

echo "🔧 Running Supabase schema migration..."
source ../.env

DB_URL="postgres://${POSTGRES_USER}:${POSTGRES_PASSWORD}@${POSTGRES_HOST}:${POSTGRES_PORT}/${POSTGRES_DB}"

if ! command -v npx &> /dev/null; then
  echo "⚠️ npx not found. Installing supabase CLI globally..."
  npm install -g supabase
fi

supabase db push --db-url "$DB_URL"
echo "✅ Migration complete."
